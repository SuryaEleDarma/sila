
<footer>
    <div class="container" style="margin-top:90px;padding-top:0px;">
        <div class="col-md-4 col-sm-4 menu">
            <nav>
                <ul>
                    <li><p class="sosmed">MENU</p></li>
                    <li><a href="">TENTANG</a></li>
                    <li ><a href="">ADMIN</a></li>
                </ul>
            </nav>
        </div>

        <div class="col-md-4 col-sm-4 menu">
            <a href=""><center><img src="<?=base_url();?>image/logo/logoBW.png" style="padding-top:20px;opacity:0.9;" class="img-responsive" height="70" width="80"></center></a>
        </div>

        <div class="col-md-2 col-md-push-2">
            <nav>
                <ul>
                    <li><p class="sosmed">Follow us on</p></li>
                        <ul class="sosmed">
                            <li><a href=""><img class="sosmed" src="<?=base_url();?>image/sosmed/fb.png"></a></li>
                            <li><a href=""><img class="sosmed" src="<?=base_url();?>image/sosmed/tw.png"></a></li>
                            <li><a href=""><img class="sosmed" src="<?=base_url();?>image/sosmed/gp.png"></a></li>
                        </ul>        
                </ul>
            </nav>
        </div>

        <div class="clear"></div>
        <div class="col-md-12 col-sm-12">
            <div class="garis"></div>
                <center><p class="copyright" style="color:#D8D8D8;font-family:'Raleway Regular'">Copyright &copy; tim #KantongAjaib</p></center>
            </div>
        </div>
    </div>
</footer>