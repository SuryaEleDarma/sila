<html>
	<header>
		<nav class="navbar navbar-default putih navbar-fixed-top">
      		<div class="container">
        		<div class="navbar-header">
                     <a class="navbar-brand" href=""><img src="<?=base_url();?>image/logo/logoHome.png" class="img-responsive logo"></a><br><br><br>  
		         
		          
		        </div>
        
        			<div id="navbar" class="navbar-collapse collapse" aria-expanded="false" style="height: 50px;">
          			 </div></li>
          				</ul>
        			</div>
     		</div>
    	</nav>
	</header>
    </html>